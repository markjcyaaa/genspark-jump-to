/**
 * Genspark 提问目录助手 v1.0.1
 * 
 * 作者: Mark Jin (使用 Genspark 生成)
 * 日期: 2026-01-15
 * 许可: 个人学习使用
 */

// Options 页面逻辑

(function() {
  'use strict';
  
  // DOM 元素
  const form = document.getElementById('settingsForm');
  const statusMessage = document.getElementById('statusMessage');
  
  const truncateCJKChars = document.getElementById('truncateCJKChars');
  const truncateENWords = document.getElementById('truncateENWords');
  const fontSizePx = document.getElementById('fontSizePx');
  const panelOpacity = document.getElementById('panelOpacity');
  const panelWidthPx = document.getElementById('panelWidthPx');
  
  const fontSizeValue = document.getElementById('fontSizeValue');
  const opacityValue = document.getElementById('opacityValue');
  const widthValue = document.getElementById('widthValue');
  
  const saveBtn = document.getElementById('saveBtn');
  const resetBtn = document.getElementById('resetBtn');
  
  // 加载配置
  async function loadSettings() {
    const config = await GSStorageUtils.getConfig();
    
    truncateCJKChars.value = config.truncateCJKChars;
    truncateENWords.value = config.truncateENWords;
    fontSizePx.value = config.fontSizePx;
    panelOpacity.value = config.panelOpacity;
    panelWidthPx.value = config.panelWidthPx;
    
    updateValueDisplays();
  }
  
  // 更新显示值
  function updateValueDisplays() {
    fontSizeValue.textContent = `${fontSizePx.value}px`;
    opacityValue.textContent = panelOpacity.value;
    widthValue.textContent = `${panelWidthPx.value}px`;
  }
  
  // 保存配置
  async function saveSettings(e) {
    e.preventDefault();
    
    try {
      const config = {
        truncateCJKChars: parseInt(truncateCJKChars.value),
        truncateENWords: parseInt(truncateENWords.value),
        fontSizePx: parseInt(fontSizePx.value),
        panelOpacity: parseFloat(panelOpacity.value),
        panelWidthPx: parseInt(panelWidthPx.value)
      };
      
      // 验证
      if (config.truncateCJKChars < 1 || config.truncateCJKChars > 50) {
        throw new Error('中文截断长度必须在 1-50 之间');
      }
      if (config.truncateENWords < 1 || config.truncateENWords > 50) {
        throw new Error('英文截断长度必须在 1-50 之间');
      }
      
      // 保存
      await GSStorageUtils.saveConfig(config);
      
      // 通知所有 Genspark 标签页更新配置
      chrome.tabs.query({ url: 'https://www.genspark.ai/*' }, (tabs) => {
        tabs.forEach(tab => {
          chrome.tabs.sendMessage(tab.id, {
            type: 'CONFIG_UPDATED',
            config: config
          }).catch(() => {
            // 忽略错误（标签页可能还没加载扩展）
          });
        });
      });
      
      showStatus('设置已保存！配置将在刷新页面后生效', 'success');
    } catch (error) {
      showStatus(`保存失败: ${error.message}`, 'error');
    }
  }
  
  // 恢复默认设置
  async function resetSettings() {
    if (!confirm('确定要恢复默认设置吗？')) {
      return;
    }
    
    await GSStorageUtils.saveConfig(GSStorageUtils.DEFAULT_CONFIG);
    await loadSettings();
    showStatus('已恢复默认设置', 'success');
  }
  
  // 显示状态消息
  function showStatus(message, type = 'success') {
    statusMessage.textContent = message;
    statusMessage.className = `status-message ${type} show`;
    
    setTimeout(() => {
      statusMessage.classList.remove('show');
    }, 3000);
  }
  
  // 事件监听
  form.addEventListener('submit', saveSettings);
  resetBtn.addEventListener('click', resetSettings);
  
  fontSizePx.addEventListener('input', updateValueDisplays);
  panelOpacity.addEventListener('input', updateValueDisplays);
  panelWidthPx.addEventListener('input', updateValueDisplays);
  
  // 初始化
  loadSettings();
  
})();
