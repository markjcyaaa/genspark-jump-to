/**
 * Genspark 提问目录助手 v1.0.1
 * 
 * 作者: Mark Jin (使用 Genspark 生成)
 * 日期: 2026-01-15
 * 许可: 个人学习使用
 */

// 配置存储模块 - 读写扩展配置

// 默认配置
const DEFAULT_CONFIG = {
  truncateCJKChars: 10,      // 中文截断字符数
  truncateENWords: 10,       // 英文截断单词数
  fontSizePx: 14,            // 字体大小（像素）
  panelOpacity: 0.75,        // 面板透明度
  panelWidthPx: 260,         // 面板宽度（像素）
  collapsed: false           // 是否折叠
};

/**
 * 获取配置（从 chrome.storage.sync）
 * @returns {Promise<Object>} 配置对象
 */
async function getConfig() {
  return new Promise((resolve) => {
    chrome.storage.sync.get(DEFAULT_CONFIG, (result) => {
      resolve(result);
    });
  });
}

/**
 * 保存配置（到 chrome.storage.sync）
 * @param {Object} config - 配置对象
 * @returns {Promise<void>}
 */
async function saveConfig(config) {
  return new Promise((resolve) => {
    chrome.storage.sync.set(config, () => {
      resolve();
    });
  });
}

/**
 * 监听配置变化
 * @param {Function} callback - 回调函数 (newConfig, oldConfig) => void
 */
function onConfigChange(callback) {
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'sync') {
      const newConfig = {};
      const oldConfig = {};
      
      for (let key in changes) {
        newConfig[key] = changes[key].newValue;
        oldConfig[key] = changes[key].oldValue;
      }
      
      callback(newConfig, oldConfig);
    }
  });
}

// 导出函数
if (typeof window !== 'undefined') {
  window.GSStorageUtils = {
    DEFAULT_CONFIG,
    getConfig,
    saveConfig,
    onConfigChange
  };
}
