/**
 * Genspark 提问目录助手 v1.0.1
 * 
 * 作者: Mark Jin (使用 Genspark 生成)
 * 日期: 2026-01-15
 * 许可: 个人学习使用
 */

// Content Script - Genspark 提问目录核心逻辑（修复版）

(function() {
  'use strict';
  
  // 全局状态
  let config = null;
  let tocItems = new Map(); // key: qid, value: { element, title, fullText }
  let tocPanel = null;
  let tocList = null;
  let observer = null;
  let isInitialized = false;
  let lastURL = location.href;
  let retryCount = 0;
  const MAX_RETRY = 3; // 最多重试3次，避免无限循环
  
  // 初始化扩展
  async function init() {
    if (isInitialized) return;
    
    console.log('[Genspark TOC] 初始化扩展...');
    
    // 加载配置
    config = await GSStorageUtils.getConfig();
    console.log('[Genspark TOC] 配置加载完成:', config);
    
    // 创建目录面板
    createTOCPanel();
    
    // 扫描现有提问
    scanQuestions();
    
    // 监听 DOM 变化
    startObserver();
    
    // 监听配置变化
    GSStorageUtils.onConfigChange(handleConfigChange);
    
    // 监听 URL 变化（SPA 路由）
    detectURLChange();
    
    isInitialized = true;
    console.log('[Genspark TOC] 初始化完成');
  }
  
  // 创建目录面板 UI
  function createTOCPanel() {
    // 创建容器
    tocPanel = document.createElement('div');
    tocPanel.id = 'gs-toc-panel';
    tocPanel.className = config.collapsed ? 'collapsed' : '';
    
    // 创建头部
    const header = document.createElement('div');
    header.className = 'gs-toc-header';
    
    const title = document.createElement('div');
    title.className = 'gs-toc-title';
    title.textContent = '提问目录';
    
    const toggleBtn = document.createElement('button');
    toggleBtn.className = 'gs-toc-toggle';
    toggleBtn.innerHTML = config.collapsed ? '◀' : '▶';
    toggleBtn.title = config.collapsed ? '展开目录' : '折叠目录';
    toggleBtn.addEventListener('click', togglePanel);
    
    header.appendChild(title);
    header.appendChild(toggleBtn);
    
    // 创建列表容器
    tocList = document.createElement('div');
    tocList.className = 'gs-toc-list';
    
    // 组装面板
    tocPanel.appendChild(header);
    tocPanel.appendChild(tocList);
    
    // 应用配置样式
    applyConfigStyles();
    
    // 添加到页面
    document.body.appendChild(tocPanel);
  }
  
  // 应用配置样式
  function applyConfigStyles() {
    if (!tocPanel) return;
    
    tocPanel.style.setProperty('--panel-opacity', config.panelOpacity);
    tocPanel.style.setProperty('--panel-width', `${config.panelWidthPx}px`);
    tocPanel.style.setProperty('--font-size', `${config.fontSizePx}px`);
  }
  
  // 切换面板折叠状态
  async function togglePanel() {
    config.collapsed = !config.collapsed;
    tocPanel.classList.toggle('collapsed');
    
    const toggleBtn = tocPanel.querySelector('.gs-toc-toggle');
    toggleBtn.innerHTML = config.collapsed ? '◀' : '▶';
    toggleBtn.title = config.collapsed ? '展开目录' : '折叠目录';
    
    // 保存状态
    await GSStorageUtils.saveConfig({ collapsed: config.collapsed });
  }
  
  // 识别"提问消息块"（修复版 - 基于实际 DOM 结构）
  function findQuestionElements() {
    const questions = [];
    
    // 根据你提供的信息，Genspark 使用这些选择器：
    // 1. div.conversation-statement.user.plain-text （优先）
    // 2. div.conversation-item-desc.user
    
    // 策略 1：优先使用最外层的用户消息容器（避免重复）
    const candidates1 = document.querySelectorAll('.conversation-statement.user');
    
    // 策略 2：如果策略1没找到，尝试其他选择器
    const candidates2 = document.querySelectorAll('.conversation-item-desc.user');
    
    // 策略 3：通用选择器（兜底）
    const candidates3 = document.querySelectorAll('[class*="user"][class*="message"], [class*="user"][class*="question"]');
    
    // 优先使用策略1，如果没找到再用策略2
    let finalCandidates = candidates1.length > 0 ? candidates1 : 
                         candidates2.length > 0 ? candidates2 : 
                         candidates3;
    
    console.log('[Genspark TOC] 候选节点数:', finalCandidates.length);
    
    for (const elem of finalCandidates) {
      // 跳过已标记的
      if (elem.hasAttribute('data-gs-qid')) {
        continue;
      }
      
      // 提取文本，确保有内容
      const text = GSTextUtils.extractText(elem);
      if (text && text.length >= 2) {
        // 确保不是AI回复（双重检查）
        const className = elem.className.toLowerCase();
        if (!className.includes('assistant') && 
            !className.includes('bot') && 
            !className.includes('ai-response')) {
          questions.push(elem);
        }
      }
    }
    
    return questions;
  }
  
  // 扫描并构建目录
  function scanQuestions() {
    const questions = findQuestionElements();
    console.log('[Genspark TOC] 找到提问节点:', questions.length);
    
    let addedCount = 0;
    questions.forEach((elem, index) => {
      const wasAdded = addQuestionToTOC(elem, index);
      if (wasAdded) addedCount++;
    });
    
    console.log('[Genspark TOC] 成功添加:', addedCount);
    
    renderTOC();
  }
  
  // 添加提问到目录（返回是否成功添加）
  function addQuestionToTOC(element, index) {
    const fullText = GSTextUtils.extractText(element);
    if (!fullText || fullText.length < 2) return false;
    
    // 生成唯一 ID（基于文本内容，避免重复）
    const textHash = GSTextUtils.simpleHash(fullText);
    const qid = `q-${textHash}`;
    
    // 检查是否已存在（基于文本哈希去重）
    if (tocItems.has(qid)) {
      console.log('[Genspark TOC] 跳过重复项:', fullText.substring(0, 20) + '...');
      return false;
    }
    
    // 标记节点
    element.setAttribute('data-gs-qid', qid);
    
    // 生成标题
    const title = GSTextUtils.truncateText(fullText, config.truncateCJKChars, config.truncateENWords);
    
    // 保存到 Map
    tocItems.set(qid, {
      element,
      title,
      fullText
    });
    
    console.log('[Genspark TOC] 添加提问:', title);
    return true;
  }
  
  // 渲染目录列表
  function renderTOC() {
    if (!tocList) return;
    
    // 清空现有列表
    tocList.innerHTML = '';
    
    if (tocItems.size === 0) {
      tocList.innerHTML = '<div class="gs-toc-empty">暂无提问</div>';
      return;
    }
    
    // 使用 DocumentFragment 提升性能
    const fragment = document.createDocumentFragment();
    
    tocItems.forEach((item, qid) => {
      const itemDiv = document.createElement('div');
      itemDiv.className = 'gs-toc-item';
      itemDiv.textContent = item.title;
      itemDiv.title = item.fullText; // 悬停显示完整文本
      itemDiv.setAttribute('data-qid', qid);
      
      // 点击跳转
      itemDiv.addEventListener('click', () => {
        scrollToQuestion(qid);
      });
      
      fragment.appendChild(itemDiv);
    });
    
    tocList.appendChild(fragment);
  }
  
  // 滚动到指定提问并高亮
  function scrollToQuestion(qid) {
    const item = tocItems.get(qid);
    if (!item || !item.element) return;
    
    // 计算滚动位置（考虑顶部固定栏）
    const elementRect = item.element.getBoundingClientRect();
    const absoluteTop = elementRect.top + window.pageYOffset;
    const offset = 80; // 顶部偏移量
    
    // 平滑滚动
    window.scrollTo({
      top: absoluteTop - offset,
      behavior: 'smooth'
    });
    
    // 高亮效果
    item.element.classList.add('gs-highlight');
    setTimeout(() => {
      item.element.classList.remove('gs-highlight');
    }, 2000);
    
    console.log('[Genspark TOC] 跳转到:', item.title);
  }
  
  // 监听 DOM 变化（MutationObserver）- 修复版
  function startObserver() {
    // 尝试找到对话容器
    const container = document.querySelector('main, [role="main"], #root, .chat-container, .conversation, .conversation-container, [class*="conversation"]');
    
    if (!container) {
      console.warn('[Genspark TOC] 未找到对话容器，将监听整个 body');
      
      // 限制重试次数，避免无限循环
      if (retryCount < MAX_RETRY) {
        retryCount++;
        setTimeout(startObserver, 2000);
        return;
      } else {
        console.warn('[Genspark TOC] 达到最大重试次数，使用 body 作为监听目标');
        // 继续使用 body，但已经警告过了
      }
    } else {
      console.log('[Genspark TOC] 找到对话容器:', container.className || container.tagName);
      retryCount = 0; // 重置重试计数
    }
    
    const targetNode = container || document.body;
    
    // 节流更新
    let updateTimeout = null;
    
    observer = new MutationObserver((mutations) => {
      clearTimeout(updateTimeout);
      updateTimeout = setTimeout(() => {
        scanQuestions();
      }, 300); // 300ms 节流
    });
    
    observer.observe(targetNode, {
      childList: true,
      subtree: true
    });
  }
  
  // 检测 URL 变化（SPA 路由）
  function detectURLChange() {
    setInterval(() => {
      if (location.href !== lastURL) {
        console.log('[Genspark TOC] URL 变化，重新初始化');
        lastURL = location.href;
        
        // 清理旧状态
        tocItems.clear();
        
        // 重置重试计数
        retryCount = 0;
        
        // 重新扫描
        setTimeout(() => {
          scanQuestions();
        }, 1000); // 等待新页面加载
      }
    }, 1000);
  }
  
  // 处理配置变化
  function handleConfigChange(newConfig) {
    console.log('[Genspark TOC] 配置已更新:', newConfig);
    
    // 合并配置
    config = { ...config, ...newConfig };
    
    // 应用新样式
    applyConfigStyles();
    
    // 重新渲染目录（标题可能需要重新截断）
    tocItems.forEach((item, qid) => {
      item.title = GSTextUtils.truncateText(item.fullText, config.truncateCJKChars, config.truncateENWords);
    });
    
    renderTOC();
  }
  
  // 页面加载完成后初始化
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    // 延迟初始化，等待 Genspark 页面渲染完成
    setTimeout(init, 1000);
  }
  
})();
