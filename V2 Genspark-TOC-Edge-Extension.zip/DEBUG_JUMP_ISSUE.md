# 🔍 跳转问题排查指南

**问题**: 点击目录项时无法跳转  
**版本**: v1.0.3  
**日期**: 2026-01-15

---

## 📋 请按以下步骤排查

### 步骤 1：打开浏览器控制台

```
1. 在 Genspark 页面按 F12
2. 切换到 "Console"（控制台）标签
3. 保持控制台打开
```

### 步骤 2：点击目录项并观察日志

```
1. 点击目录中的任意一个提问
2. 观察控制台是否输出日志
3. 查找以下关键日志：
   - [Genspark TOC] 跳转到...
   - 或者是否有红色的错误信息
```

### 步骤 3：检查目录项是否可点击

```
1. 鼠标移到目录项上时，光标是否变成手型（pointer）？
2. 目录项是否有悬停效果（背景变色）？
3. 点击时是否有任何视觉反馈？
```

### 步骤 4：检查配置

```
1. 右键扩展图标 → 选项
2. 查看 "点击跳转目标" 的设置
3. 当前是 "跳转到提问" 还是 "跳转到回答"？
```

---

## 🐛 可能的原因

### 原因 1：事件监听器未绑定
**症状**: 点击没有任何反应，控制台无日志  
**检查**: 控制台是否有 `[Genspark TOC] 添加提问: ...` 日志

### 原因 2：目标元素不存在
**症状**: 控制台有 "目标元素不存在" 警告  
**检查**: 提问是否真的在页面中

### 原因 3：scrollToTarget 函数出错
**症状**: 控制台有红色错误信息  
**检查**: 是否有 JavaScript 错误

### 原因 4：CSS 问题导致目录不可点击
**症状**: 鼠标移上去没有变成手型  
**检查**: 目录项的 cursor 样式

---

## 🔧 临时诊断代码

请在控制台运行以下代码来诊断：

### 诊断 1：检查目录数据
```javascript
// 在控制台粘贴并运行
console.log('=== 目录数据诊断 ===');
const tocPanel = document.getElementById('gs-toc-panel');
if (tocPanel) {
  console.log('✅ 目录面板存在');
  const items = tocPanel.querySelectorAll('.gs-toc-item');
  console.log('目录项数量:', items.length);
  items.forEach((item, i) => {
    console.log(`  [${i}] qid:`, item.getAttribute('data-qid'));
    console.log(`  [${i}] 文本:`, item.textContent);
  });
} else {
  console.log('❌ 目录面板不存在');
}
```

### 诊断 2：检查点击事件
```javascript
// 在控制台粘贴并运行
console.log('=== 点击事件诊断 ===');
const firstItem = document.querySelector('.gs-toc-item');
if (firstItem) {
  console.log('✅ 找到第一个目录项');
  console.log('qid:', firstItem.getAttribute('data-qid'));
  
  // 手动触发点击
  console.log('尝试手动触发点击...');
  firstItem.click();
  
  setTimeout(() => {
    console.log('如果页面跳转了，说明事件监听正常');
    console.log('如果没有跳转，说明 scrollToTarget 函数有问题');
  }, 1000);
} else {
  console.log('❌ 找不到目录项');
}
```

### 诊断 3：检查目标元素
```javascript
// 在控制台粘贴并运行
console.log('=== 目标元素诊断 ===');
const questionElements = document.querySelectorAll('[data-gs-qid]');
console.log('带 qid 的元素数量:', questionElements.length);
questionElements.forEach((el, i) => {
  const qid = el.getAttribute('data-gs-qid');
  console.log(`  [${i}] qid: ${qid}`);
  console.log(`  [${i}] 位置:`, el.getBoundingClientRect());
});
```

---

## 💬 请提供以下信息

运行完诊断代码后，请告诉我：

1. **控制台日志截图**（包含所有诊断结果）
2. **目录面板截图**（显示目录项）
3. **是否有错误信息**（红色的）
4. **点击时的配置**：
   - 跳转目标设置是什么？
   - 自动刷新是否开启？

5. **诊断结果**：
   ```
   诊断 1 结果：
   - 目录面板是否存在？
   - 目录项数量？
   
   诊断 2 结果：
   - 手动点击是否跳转？
   - 控制台有什么日志？
   
   诊断 3 结果：
   - 找到多少个带 qid 的元素？
   ```

---

## 🚑 快速修复尝试

### 尝试 1：清理并重建目录
```javascript
// 在控制台运行
console.log('清理目录数据...');
// 这需要访问扩展的内部状态，如果不行就跳过

// 手动点击刷新按钮
const refreshBtn = document.querySelector('.gs-toc-refresh');
if (refreshBtn) {
  console.log('找到刷新按钮，点击刷新...');
  refreshBtn.click();
} else {
  console.log('找不到刷新按钮');
}
```

### 尝试 2：重新加载扩展
```
1. edge://extensions/
2. 找到扩展
3. 点击 🔄 重新加载
4. 刷新 Genspark 页面（F5）
5. 重新测试
```

### 尝试 3：检查是否有 JavaScript 错误
```
1. F12 → Console
2. 清空控制台（右键 → Clear console）
3. 刷新页面（F5）
4. 发送几条提问
5. 点击目录项
6. 查看是否有红色错误
```

---

等待你的诊断结果，我会根据具体情况修复问题！🔧
