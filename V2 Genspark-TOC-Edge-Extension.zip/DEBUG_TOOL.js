/**
 * Genspark TOC 跳转问题调试工具
 * 在 Genspark 页面的控制台（F12）中粘贴并运行此代码
 */

console.log('%c=== Genspark TOC 调试工具 ===', 'color: #4a9eff; font-size: 16px; font-weight: bold;');

// 1. 检查扩展是否加载
console.log('\n%c[1] 检查扩展加载状态', 'color: #4a9eff; font-weight: bold;');
const tocPanel = document.getElementById('gs-toc-panel');
if (tocPanel) {
  console.log('✅ 目录面板存在');
} else {
  console.log('❌ 目录面板不存在 - 扩展可能未加载');
  console.log('   解决: 重新加载扩展并刷新页面');
}

// 2. 检查目录项
console.log('\n%c[2] 检查目录项', 'color: #4a9eff; font-weight: bold;');
const tocItems = document.querySelectorAll('.gs-toc-item');
console.log(`找到 ${tocItems.length} 个目录项`);

if (tocItems.length === 0) {
  console.log('❌ 没有目录项');
  console.log('   可能原因:');
  console.log('   1. 没有发送提问');
  console.log('   2. DOM 识别失败');
  console.log('   3. 点击刷新按钮试试');
} else {
  tocItems.forEach((item, i) => {
    const qid = item.getAttribute('data-qid');
    const text = item.textContent;
    console.log(`  [${i}] qid: ${qid}, text: "${text}"`);
  });
}

// 3. 检查点击事件监听器
console.log('\n%c[3] 测试点击事件', 'color: #4a9eff; font-weight: bold;');
if (tocItems.length > 0) {
  const firstItem = tocItems[0];
  const qid = firstItem.getAttribute('data-qid');
  
  // 检查是否有点击监听器
  const listeners = getEventListeners ? getEventListeners(firstItem) : null;
  if (listeners && listeners.click) {
    console.log('✅ 第一个目录项有点击监听器:', listeners.click.length, '个');
  } else {
    console.log('⚠️  无法检测监听器（Chrome DevTools 功能）');
  }
  
  // 手动触发点击测试
  console.log('即将手动触发点击第一个目录项...');
  console.log('qid:', qid);
  
  setTimeout(() => {
    console.log('→ 触发点击');
    firstItem.click();
    
    setTimeout(() => {
      console.log('如果页面跳转了 = 事件监听正常 ✅');
      console.log('如果没有跳转 = scrollToTarget 函数有问题 ❌');
    }, 500);
  }, 2000);
} else {
  console.log('❌ 没有目录项，跳过点击测试');
}

// 4. 检查目标元素
console.log('\n%c[4] 检查目标元素（提问）', 'color: #4a9eff; font-weight: bold;');
const questionElements = document.querySelectorAll('[data-gs-qid]');
console.log(`找到 ${questionElements.length} 个带 data-gs-qid 的元素`);

if (questionElements.length === 0) {
  console.log('❌ 没有找到任何提问元素');
  console.log('   这意味着 DOM 识别失败');
  console.log('   需要检查 findQuestionElements() 的选择器');
} else {
  questionElements.forEach((el, i) => {
    const qid = el.getAttribute('data-gs-qid');
    const rect = el.getBoundingClientRect();
    const visible = rect.top >= 0 && rect.top <= window.innerHeight;
    console.log(`  [${i}] qid: ${qid}`);
    console.log(`       位置: top=${Math.round(rect.top)}px, 可见=${visible}`);
  });
}

// 5. 检查样式
console.log('\n%c[5] 检查目录项样式', 'color: #4a9eff; font-weight: bold;');
if (tocItems.length > 0) {
  const firstItem = tocItems[0];
  const styles = window.getComputedStyle(firstItem);
  console.log('cursor:', styles.cursor);
  console.log('pointer-events:', styles.pointerEvents);
  console.log('z-index:', styles.zIndex);
  
  if (styles.cursor !== 'pointer') {
    console.log('❌ cursor 不是 pointer');
  } else {
    console.log('✅ cursor 正常');
  }
  
  if (styles.pointerEvents === 'none') {
    console.log('❌ pointer-events 被禁用');
  } else {
    console.log('✅ pointer-events 正常');
  }
}

// 6. 检查配置
console.log('\n%c[6] 检查扩展配置', 'color: #4a9eff; font-weight: bold;');
chrome.storage.sync.get(null, (config) => {
  console.log('当前配置:', config);
  console.log('跳转目标:', config.jumpTarget || 'question (默认)');
  console.log('自动刷新:', config.autoRefreshOnLoad !== false ? '开启' : '关闭');
});

// 7. 监听下一次点击
console.log('\n%c[7] 监听下一次点击', 'color: #4a9eff; font-weight: bold;');
console.log('请点击任意目录项，将捕获并显示详细信息...');

if (tocItems.length > 0) {
  tocItems.forEach((item, i) => {
    item.addEventListener('click', function(e) {
      console.log(`\n%c→ 目录项 [${i}] 被点击`, 'color: #ff9800; font-weight: bold;');
      console.log('qid:', item.getAttribute('data-qid'));
      console.log('text:', item.textContent);
      console.log('event:', e);
      
      // 检查对应的提问元素是否存在
      const qid = item.getAttribute('data-qid');
      const questionEl = document.querySelector(`[data-gs-qid="${qid}"]`);
      
      if (questionEl) {
        console.log('✅ 找到对应的提问元素');
        const rect = questionEl.getBoundingClientRect();
        console.log('提问元素位置:', {
          top: Math.round(rect.top),
          left: Math.round(rect.left),
          visible: rect.top >= 0 && rect.top <= window.innerHeight
        });
      } else {
        console.log('❌ 找不到对应的提问元素');
        console.log('   qid:', qid);
      }
    }, { capture: true });
  });
}

console.log('\n%c=== 调试工具加载完成 ===', 'color: #4caf50; font-size: 16px; font-weight: bold;');
console.log('等待 2 秒后将自动点击第一个目录项进行测试...');
