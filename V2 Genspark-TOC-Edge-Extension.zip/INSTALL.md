# Genspark 提问目录助手 v1.0.3 稳定版

**作者**: Mark Jin (使用 Genspark 生成)  
**版本**: v1.0.3  
**发布日期**: 2026-01-15

---

## 📦 快速安装

1. 打开 Edge 浏览器
2. 访问 `edge://extensions/`
3. 启用"开发人员模式"（右上角）
4. 点击"加载解压缩的扩展"
5. 选择本文件夹
6. 完成！

---

## 🎯 使用说明

### 基础使用
1. 访问 `https://www.genspark.ai/`
2. 发送提问
3. 查看右侧目录面板
4. 点击目录项快速跳转

### 自定义设置
1. `edge://extensions/` → 扩展详情 → 扩展选项
2. 调整字体大小、透明度、宽度等
3. 保存后刷新 Genspark 页面

---

## ✨ 功能特性

- ✅ 自动生成用户提问目录
- ✅ 智能文本截断（中英文混合）
- ✅ 点击跳转 + 高亮显示
- ✅ 实时动态更新
- ✅ 折叠/展开面板
- ✅ 5个可自定义参数
- ✅ 支持历史对话扫描

---

## 🔧 技术信息

- **标准**: Manifest V3
- **兼容**: Edge / Chrome 88+
- **权限**: 仅访问 genspark.ai
- **存储**: chrome.storage.sync

---

## 📁 项目结构

```
genspark-toc-extension/
├── manifest.json              # 扩展配置
├── README.md                  # 主文档
├── INSTALL.md                 # 本文件
└── src/
    ├── content/               # 内容脚本
    │   ├── content-script.js
    │   └── ui.css
    ├── options/               # 设置页面
    │   ├── options.html
    │   └── options.js
    └── shared/                # 共享模块
        ├── storage.js
        └── text.js
```

---

## 🐛 故障排除

### 目录为空
1. 按 `F12` 打开控制台
2. 查找 `[Genspark TOC]` 日志
3. 确认找到提问节点数量 > 0

### 扩展未加载
1. 检查扩展是否启用
2. 刷新 Genspark 页面
3. 重新加载扩展

---

## 📝 更新日志

### v1.0.1 (2026-01-15) - 稳定版
- 修复重复识别问题
- 优化 DOM 选择器
- 限制重试次数
- 改进日志输出

---

## 👤 作者

**Mark Jin**  
使用 Genspark 生成

---

**祝使用愉快！** 🚀
