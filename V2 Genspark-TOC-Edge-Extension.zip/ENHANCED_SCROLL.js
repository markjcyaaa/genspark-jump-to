/**
 * Genspark 提问目录助手 - 增强跳转修复版
 * 
 * 此版本增强了 scrollToTarget 函数的健壮性
 * 解决可能的跳转失败问题
 */

// 备用的 scrollToTarget 函数（如果原版不工作，可以替换）
function scrollToTarget_Enhanced(qid) {
  console.log('[Genspark TOC] scrollToTarget 被调用, qid:', qid);
  
  // 从全局 tocItems 获取数据（需要确保这个变量可访问）
  // 注意：这里假设 tocItems 是全局可访问的
  
  // 方法1: 直接通过 data-qid 查找元素（最可靠）
  const questionElement = document.querySelector(`[data-gs-qid="${qid}"]`);
  
  if (!questionElement) {
    console.error('[Genspark TOC] 找不到提问元素, qid:', qid);
    alert('跳转失败：找不到目标元素');
    return;
  }
  
  console.log('[Genspark TOC] 找到提问元素:', questionElement);
  
  // 方法2: 使用 scrollIntoView（更简单可靠）
  try {
    questionElement.scrollIntoView({
      behavior: 'smooth',
      block: 'center', // 滚动到视窗中央
      inline: 'nearest'
    });
    
    console.log('[Genspark TOC] scrollIntoView 执行成功');
    
    // 高亮效果
    questionElement.style.transition = 'background-color 0.3s';
    questionElement.style.backgroundColor = 'rgba(255, 255, 0, 0.3)';
    
    setTimeout(() => {
      questionElement.style.backgroundColor = '';
    }, 2000);
    
    console.log('[Genspark TOC] 高亮效果已添加');
    
  } catch (error) {
    console.error('[Genspark TOC] scrollIntoView 出错:', error);
    
    // 回退方案：使用传统滚动
    try {
      const rect = questionElement.getBoundingClientRect();
      const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
      const targetY = rect.top + scrollTop - 100;
      
      window.scrollTo({
        top: targetY,
        behavior: 'smooth'
      });
      
      console.log('[Genspark TOC] 使用回退滚动方案成功');
    } catch (error2) {
      console.error('[Genspark TOC] 回退滚动也失败:', error2);
      alert('跳转失败：' + error2.message);
    }
  }
}

// 测试函数：手动跳转到第一个提问
function testJump() {
  console.log('=== 测试跳转功能 ===');
  
  // 找到第一个目录项
  const firstTocItem = document.querySelector('.gs-toc-item');
  if (!firstTocItem) {
    console.log('❌ 找不到目录项');
    return;
  }
  
  const qid = firstTocItem.getAttribute('data-qid');
  console.log('第一个目录项的 qid:', qid);
  
  // 测试跳转
  scrollToTarget_Enhanced(qid);
}

console.log('增强跳转函数已加载');
console.log('运行 testJump() 可以测试跳转到第一个提问');
