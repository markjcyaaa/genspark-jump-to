/**
 * Genspark 提问目录助手 v1.0.3
 * 
 * 作者: Mark Jin (使用 Genspark 生成)
 * 日期: 2026-01-15
 * 许可: 个人学习使用
 */

// 文本处理工具模块 - 提取和截断文本

/**
 * 从 DOM 节点提取纯文本内容
 * @param {HTMLElement} element - DOM 节点
 * @returns {string} 提取的纯文本
 */
function extractText(element) {
  if (!element) return '';
  
  // 获取纯文本内容
  let text = element.innerText || element.textContent || '';
  
  // 清理文本：去除多余空白、换行
  text = text
    .replace(/\s+/g, ' ')  // 多个空白字符合并为一个空格
    .replace(/^\s+|\s+$/g, '')  // 去除首尾空白
    .trim();
  
  return text;
}

/**
 * 统计文本中的中文字符数（CJK）
 * @param {string} text - 输入文本
 * @returns {number} 中文字符数
 */
function countCJKChars(text) {
  const cjkRegex = /[\u4e00-\u9fff\u3400-\u4dbf\u{20000}-\u{2a6df}\u{2a700}-\u{2b73f}\u{2b740}-\u{2b81f}\u{2b820}-\u{2ceaf}\uf900-\ufaff\u3300-\u33ff\ufe30-\ufe4f\uf900-\ufaff\u{2f800}-\u{2fa1f}]/gu;
  const matches = text.match(cjkRegex);
  return matches ? matches.length : 0;
}

/**
 * 统计文本中的英文单词数
 * @param {string} text - 输入文本
 * @returns {number} 英文单词数
 */
function countEnglishWords(text) {
  // 移除中文字符后再统计英文单词
  const textWithoutCJK = text.replace(/[\u4e00-\u9fff\u3400-\u4dbf\u{20000}-\u{2a6df}\u{2a700}-\u{2b73f}\u{2b740}-\u{2b81f}\u{2b820}-\u{2ceaf}\uf900-\ufaff\u3300-\u33ff\ufe30-\ufe4f\uf900-\ufaff\u{2f800}-\u{2fa1f}]/gu, '');
  const words = textWithoutCJK.match(/[a-zA-Z]+/g);
  return words ? words.length : 0;
}

/**
 * 智能截断文本（同时限制中文字符数和英文单词数）
 * @param {string} text - 原始文本
 * @param {number} maxCJKChars - 最大中文字符数
 * @param {number} maxEnWords - 最大英文单词数
 * @returns {string} 截断后的文本
 */
function truncateText(text, maxCJKChars = 10, maxEnWords = 10) {
  if (!text) return '';
  
  let result = '';
  let cjkCount = 0;
  let enWordCount = 0;
  let currentWord = '';
  
  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    const isCJK = /[\u4e00-\u9fff\u3400-\u4dbf\u{20000}-\u{2a6df}\u{2a700}-\u{2b73f}\u{2b740}-\u{2b81f}\u{2b820}-\u{2ceaf}\uf900-\ufaff\u3300-\u33ff\ufe30-\ufe4f\uf900-\ufaff\u{2f800}-\u{2fa1f}]/u.test(char);
    const isEnglish = /[a-zA-Z]/.test(char);
    
    if (isCJK) {
      // 处理当前积累的英文单词
      if (currentWord) {
        enWordCount++;
        if (enWordCount > maxEnWords) {
          return result + '…';
        }
        result += currentWord;
        currentWord = '';
      }
      
      // 处理中文字符
      cjkCount++;
      if (cjkCount > maxCJKChars) {
        return result + '…';
      }
      result += char;
    } else if (isEnglish) {
      // 积累英文字符
      currentWord += char;
    } else {
      // 处理当前积累的英文单词
      if (currentWord) {
        enWordCount++;
        if (enWordCount > maxEnWords) {
          return result + '…';
        }
        result += currentWord;
        currentWord = '';
      }
      
      // 添加非字母非中文字符（空格、标点等）
      result += char;
    }
  }
  
  // 处理最后的英文单词
  if (currentWord) {
    enWordCount++;
    if (enWordCount > maxEnWords) {
      return result + '…';
    }
    result += currentWord;
  }
  
  return result;
}

/**
 * 生成简单的文本哈希（用于生成唯一 ID）
 * @param {string} text - 输入文本
 * @returns {string} 哈希值
 */
function simpleHash(text) {
  let hash = 0;
  for (let i = 0; i < text.length; i++) {
    const char = text.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32bit integer
  }
  return Math.abs(hash).toString(36);
}

// 导出函数（在扩展环境中使用）
if (typeof window !== 'undefined') {
  window.GSTextUtils = {
    extractText,
    countCJKChars,
    countEnglishWords,
    truncateText,
    simpleHash
  };
}
