/**
 * Genspark 提问目录助手 v1.0.4
 * 
 * 作者: Mark Jin (使用 Genspark 生成)
 * 日期: 2026-01-15
 * 许可: 个人学习使用
 */

// Content Script - Genspark 提问目录核心逻辑

(function() {
  'use strict';
  
  // 全局状态
  let config = null;
  let tocItems = new Map(); // key: qid, value: { questionElement, answerElement, title, fullText }
  let tocPanel = null;
  let tocList = null;
  let observer = null;
  let isInitialized = false;
  let lastURL = location.href;
  let retryCount = 0;
  const MAX_RETRY = 3;
  let loadMoreBtnMonitored = false; // 防止重复监听
  
  // 初始化扩展
  async function init() {
    if (isInitialized) return;
    
    console.log('[Genspark TOC] 初始化扩展...');
    
    // 加载配置
    config = await GSStorageUtils.getConfig();
    console.log('[Genspark TOC] 配置加载完成:', config);
    
    // 创建目录面板
    createTOCPanel();
    
    // 扫描现有提问
    scanQuestions();
    
    // 监听 DOM 变化
    startObserver();
    
    // 监听"加载较早的消息"按钮
    monitorLoadMoreButton();
    
    // 监听配置变化
    GSStorageUtils.onConfigChange(handleConfigChange);
    
    // 监听 URL 变化（SPA 路由）
    detectURLChange();
    
    isInitialized = true;
    console.log('[Genspark TOC] 初始化完成');
  }
  
  // 创建目录面板 UI
  function createTOCPanel() {
    // 创建容器
    tocPanel = document.createElement('div');
    tocPanel.id = 'gs-toc-panel';
    tocPanel.className = config.collapsed ? 'collapsed' : '';
    
    // 创建头部
    const header = document.createElement('div');
    header.className = 'gs-toc-header';
    
    const title = document.createElement('div');
    title.className = 'gs-toc-title';
    title.textContent = '提问目录';
    
    // 按钮容器
    const btnGroup = document.createElement('div');
    btnGroup.className = 'gs-toc-btn-group';
    
    // 刷新按钮
    const refreshBtn = document.createElement('button');
    refreshBtn.className = 'gs-toc-refresh';
    refreshBtn.innerHTML = '🔄';
    refreshBtn.title = '刷新目录（扫描新加载的消息）';
    refreshBtn.addEventListener('click', () => {
      console.log('[Genspark TOC] 手动刷新目录...');
      scanQuestions();
      showToast('目录已更新！');
    });
    
    // 折叠按钮
    const toggleBtn = document.createElement('button');
    toggleBtn.className = 'gs-toc-toggle';
    toggleBtn.innerHTML = config.collapsed ? '◀' : '▶';
    toggleBtn.title = config.collapsed ? '展开目录' : '折叠目录';
    toggleBtn.addEventListener('click', togglePanel);
    
    btnGroup.appendChild(refreshBtn);
    btnGroup.appendChild(toggleBtn);
    
    header.appendChild(title);
    header.appendChild(btnGroup);
    
    // 创建列表容器
    tocList = document.createElement('div');
    tocList.className = 'gs-toc-list';
    
    // 组装面板
    tocPanel.appendChild(header);
    tocPanel.appendChild(tocList);
    
    // 应用配置样式
    applyConfigStyles();
    
    // 添加到页面
    document.body.appendChild(tocPanel);
  }
  
  // 显示提示消息
  function showToast(message, duration = 2000) {
    const toast = document.createElement('div');
    toast.className = 'gs-toast';
    toast.textContent = message;
    tocPanel.appendChild(toast);
    
    setTimeout(() => {
      toast.classList.add('show');
    }, 10);
    
    setTimeout(() => {
      toast.classList.remove('show');
      setTimeout(() => {
        toast.remove();
      }, 300);
    }, duration);
  }
  
  // 应用配置样式
  function applyConfigStyles() {
    if (!tocPanel) return;
    
    tocPanel.style.setProperty('--panel-opacity', config.panelOpacity);
    tocPanel.style.setProperty('--panel-width', `${config.panelWidthPx}px`);
    tocPanel.style.setProperty('--font-size', `${config.fontSizePx}px`);
  }
  
  // 切换面板折叠状态
  async function togglePanel() {
    config.collapsed = !config.collapsed;
    tocPanel.classList.toggle('collapsed');
    
    const toggleBtn = tocPanel.querySelector('.gs-toc-toggle');
    toggleBtn.innerHTML = config.collapsed ? '◀' : '▶';
    toggleBtn.title = config.collapsed ? '展开目录' : '折叠目录';
    
    await GSStorageUtils.saveConfig({ collapsed: config.collapsed });
  }
  
  // 识别"提问消息块"
  function findQuestionElements() {
    const questions = [];
    
    const candidates1 = document.querySelectorAll('.conversation-statement.user');
    const candidates2 = document.querySelectorAll('.conversation-item-desc.user');
    const candidates3 = document.querySelectorAll('[class*="user"][class*="message"], [class*="user"][class*="question"]');
    
    let finalCandidates = candidates1.length > 0 ? candidates1 : 
                         candidates2.length > 0 ? candidates2 : 
                         candidates3;
    
    console.log('[Genspark TOC] 候选节点数:', finalCandidates.length);
    
    for (const elem of finalCandidates) {
      if (elem.hasAttribute('data-gs-qid')) continue;
      
      const text = GSTextUtils.extractText(elem);
      if (text && text.length >= 2) {
        const className = elem.className.toLowerCase();
        if (!className.includes('assistant') && 
            !className.includes('bot') && 
            !className.includes('ai-response')) {
          questions.push(elem);
        }
      }
    }
    
    return questions;
  }
  
  // 查找对应的 AI 回答元素
  function findAnswerElement(questionElement) {
    // 策略 1: 查找下一个兄弟元素中的回答
    let nextElement = questionElement.nextElementSibling;
    while (nextElement) {
      const className = nextElement.className ? nextElement.className.toLowerCase() : '';
      
      if (className.includes('assistant') || 
          className.includes('bot') || 
          className.includes('ai') ||
          nextElement.querySelector('.bubble[message-content-id]')) {
        console.log('[Genspark TOC] 找到对应回答 (策略1)');
        return nextElement;
      }
      
      nextElement = nextElement.nextElementSibling;
    }
    
    // 策略 2: 查找父元素的兄弟元素中的回答
    const parent = questionElement.parentElement;
    if (parent) {
      let nextParent = parent.nextElementSibling;
      while (nextParent) {
        const answerInParent = nextParent.querySelector('.bubble[message-content-id], [class*="assistant"], [class*="ai-message"]');
        if (answerInParent) {
          console.log('[Genspark TOC] 找到对应回答 (策略2)');
          return answerInParent;
        }
        nextParent = nextParent.nextElementSibling;
      }
    }
    
    // 策略 3: 基于位置查找最近的回答
    const allBubbles = document.querySelectorAll('.bubble[message-content-id]');
    const questionRect = questionElement.getBoundingClientRect();
    
    for (const bubble of allBubbles) {
      const bubbleRect = bubble.getBoundingClientRect();
      if (bubbleRect.top > questionRect.top) {
        console.log('[Genspark TOC] 找到对应回答 (策略3)');
        return bubble;
      }
    }
    
    console.warn('[Genspark TOC] 未找到对应回答');
    return null;
  }
  
  // 扫描并构建目录
  function scanQuestions() {
    const questions = findQuestionElements();
    console.log('[Genspark TOC] 找到提问节点:', questions.length);
    
    let addedCount = 0;
    questions.forEach((elem, index) => {
      const wasAdded = addQuestionToTOC(elem, index);
      if (wasAdded) addedCount++;
    });
    
    console.log('[Genspark TOC] 成功添加:', addedCount);
    
    renderTOC();
  }
  
  // 添加提问到目录
  function addQuestionToTOC(questionElement, index) {
    const fullText = GSTextUtils.extractText(questionElement);
    if (!fullText || fullText.length < 2) return false;
    
    const textHash = GSTextUtils.simpleHash(fullText);
    const qid = `q-${textHash}`;
    
    if (tocItems.has(qid)) {
      console.log('[Genspark TOC] 跳过重复项:', fullText.substring(0, 20) + '...');
      return false;
    }
    
    questionElement.setAttribute('data-gs-qid', qid);
    
    // 查找对应的 AI 回答
    const answerElement = findAnswerElement(questionElement);
    
    const title = GSTextUtils.truncateText(fullText, config.truncateCJKChars, config.truncateENWords);
    
    tocItems.set(qid, {
      questionElement,
      answerElement,
      title,
      fullText
    });
    
    console.log('[Genspark TOC] 添加提问:', title);
    return true;
  }
  
  // 渲染目录列表
  function renderTOC() {
    if (!tocList) return;
    
    tocList.innerHTML = '';
    
    if (tocItems.size === 0) {
      tocList.innerHTML = '<div class="gs-toc-empty">暂无提问</div>';
      return;
    }
    
    const fragment = document.createDocumentFragment();
    
    tocItems.forEach((item, qid) => {
      const itemDiv = document.createElement('div');
      itemDiv.className = 'gs-toc-item';
      itemDiv.textContent = item.title;
      itemDiv.title = item.fullText;
      itemDiv.setAttribute('data-qid', qid);
      
      itemDiv.addEventListener('click', () => {
        scrollToTarget(qid);
      });
      
      fragment.appendChild(itemDiv);
    });
    
    tocList.appendChild(fragment);
  }
  
  // 滚动到目标位置（根据配置决定跳转到提问还是回答）
  function scrollToTarget(qid) {
    const item = tocItems.get(qid);
    if (!item) return;
    
    // 根据配置决定跳转目标
    let targetElement;
    let targetName;
    
    if (config.jumpTarget === 'answer' && item.answerElement) {
      targetElement = item.answerElement;
      targetName = 'AI回答';
    } else if (config.jumpTarget === 'answer' && !item.answerElement) {
      // 想跳转到回答但找不到，回退到提问
      targetElement = item.questionElement;
      targetName = '用户提问（回答未找到）';
    } else {
      targetElement = item.questionElement;
      targetName = '用户提问';
    }
    
    if (!targetElement) {
      console.warn('[Genspark TOC] 目标元素不存在');
      return;
    }
    
    // 使用 scrollIntoView 进行滚动（更可靠）
    try {
      targetElement.scrollIntoView({
        behavior: 'smooth',
        block: 'center',
        inline: 'nearest'
      });
      
      console.log(`[Genspark TOC] 跳转到${targetName}:`, item.title);
    } catch (error) {
      console.error('[Genspark TOC] 滚动失败:', error);
    }
    
    // 高亮效果
    targetElement.classList.add('gs-highlight');
    setTimeout(() => {
      targetElement.classList.remove('gs-highlight');
    }, 2000);
  }
  
  // 监听"加载较早的消息"按钮
  function monitorLoadMoreButton() {
    if (loadMoreBtnMonitored) return;
    
    // 定期检查按钮是否存在
    const checkInterval = setInterval(() => {
      const loadMoreBtn = document.querySelector('.load-chat-session');
      
      if (loadMoreBtn && !loadMoreBtn.hasAttribute('data-gs-monitored')) {
        console.log('[Genspark TOC] 检测到"加载较早的消息"按钮');
        loadMoreBtn.setAttribute('data-gs-monitored', 'true');
        
        // 监听点击事件
        loadMoreBtn.addEventListener('click', () => {
          if (config.autoRefreshOnLoad) {
            console.log('[Genspark TOC] 检测到加载更多，将在 2 秒后自动刷新目录');
            
            setTimeout(() => {
              scanQuestions();
              showToast('目录已自动更新！');
            }, 2000);
          }
        });
      }
    }, 2000);
    
    loadMoreBtnMonitored = true;
  }
  
  // 监听 DOM 变化
  function startObserver() {
    const container = document.querySelector('main, [role="main"], #root, .chat-container, .conversation, .conversation-container, [class*="conversation"]');
    
    if (!container) {
      console.warn('[Genspark TOC] 未找到对话容器，将监听整个 body');
      
      if (retryCount < MAX_RETRY) {
        retryCount++;
        setTimeout(startObserver, 2000);
        return;
      } else {
        console.warn('[Genspark TOC] 达到最大重试次数，使用 body 作为监听目标');
      }
    } else {
      console.log('[Genspark TOC] 找到对话容器:', container.className || container.tagName);
      retryCount = 0;
    }
    
    const targetNode = container || document.body;
    
    let updateTimeout = null;
    
    observer = new MutationObserver((mutations) => {
      clearTimeout(updateTimeout);
      updateTimeout = setTimeout(() => {
        scanQuestions();
      }, 300);
    });
    
    observer.observe(targetNode, {
      childList: true,
      subtree: true
    });
  }
  
  // 检测 URL 变化
  function detectURLChange() {
    setInterval(() => {
      if (location.href !== lastURL) {
        console.log('[Genspark TOC] URL 变化，重新初始化');
        lastURL = location.href;
        
        tocItems.clear();
        retryCount = 0;
        loadMoreBtnMonitored = false;
        
        setTimeout(() => {
          scanQuestions();
          monitorLoadMoreButton();
        }, 1000);
      }
    }, 1000);
  }
  
  // 处理配置变化
  function handleConfigChange(newConfig) {
    console.log('[Genspark TOC] 配置已更新:', newConfig);
    
    config = { ...config, ...newConfig };
    
    applyConfigStyles();
    
    tocItems.forEach((item, qid) => {
      item.title = GSTextUtils.truncateText(item.fullText, config.truncateCJKChars, config.truncateENWords);
    });
    
    renderTOC();
  }
  
  // 页面加载完成后初始化
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    setTimeout(init, 1000);
  }
  
})();
